package org.sefglobal.core.partnership.beans;

public enum Status {
    ACTIVE,
    INACTIVE,
    REMOVED
}
